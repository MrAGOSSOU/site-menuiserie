import numpy as np, cv2
from PIL import Image
src=cv2.imread('/mnt/user-data/uploads/LOGO.jpg').astype(np.float32)  # BGR
mx=src.max(2)
bg=cv2.medianBlur(np.clip(mx,0,255).astype(np.uint8),71).astype(np.float32)
bg=cv2.GaussianBlur(bg,(0,0),25)
d=mx-bg
a=np.clip((d-8)/70.0,0,1)
a=a**0.9
# un-premultiply colour against local bg
bgc=np.stack([bg*(src[...,i].mean()/max(mx.mean(),1)) for i in range(3)],2)*0+bg[...,None]*np.array([0.97,0.98,1.0])
col=np.where(a[...,None]>0.02,(src-bgc*(1-a[...,None]))/np.maximum(a[...,None],0.02),src)
col=np.clip(col,0,255)
rgba=np.dstack([col[...,2],col[...,1],col[...,0],a*255]).astype(np.uint8)
im=Image.fromarray(rgba,'RGBA')
im.save('assets/logo_full.png')
# symbol only (left part) and wordmark crop for vertical layout use
sym=im.crop((150,85,500,425)); sym.save('assets/logo_symbol.png')
# preview on black and on wood
prev=Image.new('RGBA',im.size,(8,8,8,255)); prev.alpha_composite(im); prev.convert('RGB').save('check/logo_on_black.jpg')
print(im.size, a.mean())
