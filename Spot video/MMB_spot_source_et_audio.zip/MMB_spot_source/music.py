"""MEILLEURE MENUISERIE DU BÉNIN — identité sonore « Architectural Mystery Luxury »
Composition 100 % originale, synthétisée (aucun sample externe). 48 kHz stéréo, 45 s.
Sorties dans audio/ : music.wav, sfx.wav, mix_sans_vo.wav, bed_pour_vo.wav (ducké -5 dB sur les phrases),
signature_sonore.wav (logo sonore réutilisable, 4 s).
"""
import numpy as np, scipy.signal as ss, scipy.io.wavfile as wf, os
SR = 48000; DUR = 45.0; N = int(SR * DUR)
rng = np.random.default_rng(2020)
os.makedirs('audio', exist_ok=True)

def tt(d): return np.arange(int(d * SR)) / SR
def hz(n): return 440 * 2 ** ((n - 69) / 12)            # MIDI -> Hz
NOTE = {'C':0,'C#':1,'D':2,'Eb':3,'E':4,'F':5,'F#':6,'G':7,'Ab':8,'A':9,'Bb':10,'B':11}
def m(s): return NOTE[s[:-1]] + 12 * (int(s[-1]) + 1)  # 'D3' -> 50

class Bus:
    def __init__(s): s.L = np.zeros(N + SR * 6); s.R = np.zeros(N + SR * 6)
    def add(s, t0, x, g=1.0, pan=0.0):
        i = int(t0 * SR); x = np.asarray(x) * g
        if x.ndim == 1: l, r = x * np.sqrt((1 - pan) / 2), x * np.sqrt((1 + pan) / 2)
        else: l, r = x[0], x[1]
        j = min(len(s.L), i + len(l)); s.L[i:j] += l[:j - i]; s.R[i:j] += r[:j - i]

def lp(x, fc, order=2): b, a = ss.butter(order, min(fc, SR / 2.2) / (SR / 2)); return ss.lfilter(b, a, x)
def hp(x, fc, order=2): b, a = ss.butter(order, fc / (SR / 2), 'high'); return ss.lfilter(b, a, x)
def bp(x, lo, hi, order=2): b, a = ss.butter(order, [lo / (SR / 2), min(hi, SR / 2.2) / (SR / 2)], 'band'); return ss.lfilter(b, a, x)
def env_ar(n, a, r):
    t = np.arange(n) / SR; return np.minimum(1, t / max(a, 1e-4)) * np.exp(-t / r)
def sweep_filter(x, f0, f1, kind='lp', shape=1.0):
    """filtre à coupure variable (one-pole x2) pour whoosh/risers"""
    n = len(x); f = f0 * (f1 / f0) ** (np.linspace(0, 1, n) ** shape)
    a = np.exp(-2 * np.pi * f / SR); y = np.zeros(n); z1 = z2 = 0.0
    for i in range(n):
        z1 = (1 - a[i]) * x[i] + a[i] * z1; z2 = (1 - a[i]) * z1 + a[i] * z2; y[i] = z2
    return y if kind == 'lp' else x - y

# ------------------------------------------------------------------ instruments
def piano(note, dur=4.0, vel=.6, bright=1.0):
    f = hz(note); t = tt(dur); B = 0.00035; y = np.zeros_like(t)
    for n in range(1, 14):
        fn = f * n * np.sqrt(1 + B * n * n)
        if fn > 16000: break
        amp = (1 / n ** 1.15) * (vel ** (0.5 + 0.12 * n * (1.2 - bright)))
        dec = 1 / (0.35 + 0.22 * n + f / 900)
        y += amp * np.sin(2 * np.pi * fn * t + rng.random() * 6.28) * np.exp(-t / (dec * 3.2))
    ham = lp(rng.normal(0, 1, len(t)), 2500) * np.exp(-t / 0.012) * 0.25
    y = (y + ham) * np.minimum(1, t / 0.003)
    y *= np.minimum(1, (dur - t) / 0.3)
    return lp(y, 7000 * bright + 1500) * vel

def bell(note, dur=5.0, vel=.4):           # résonance métal / verre
    f = hz(note); t = tt(dur); y = np.zeros_like(t)
    for r, a, d in [(1, 1, 3.2), (2.76, .55, 2.0), (5.40, .32, 1.2), (8.93, .18, .7), (13.34, .09, .4)]:
        y += a * np.sin(2 * np.pi * f * r * t + rng.random() * 6) * np.exp(-t / d) * (1 + .15 * np.sin(2 * np.pi * (0.7 + r * .3) * t))
    return y * np.minimum(1, t / 0.002) * vel * 0.45

def pad(notes, dur, cutoff=900, vel=.18, att=1.6, rel=1.8):
    t = tt(dur); L = np.zeros_like(t); R = np.zeros_like(t)
    for note in notes:
        f = hz(note)
        for k, det in enumerate([-0.11, 0.0, 0.09]):
            ph = rng.random(); fr = f * 2 ** (det / 12 * 0.6)
            sig = np.zeros_like(t)
            for h in range(1, 12):
                if fr * h > cutoff * 2.5: break
                sig += np.sin(2 * np.pi * fr * h * t + ph * h) / h
            pan = (k - 1) * .6
            L += sig * np.sqrt((1 - pan) / 2); R += sig * np.sqrt((1 + pan) / 2)
    e = np.minimum(1, t / att) * np.minimum(1, (dur - t) / rel)
    L = lp(L * e, cutoff); R = lp(R * e, cutoff)
    return np.array([L, R]) * vel / max(1, len(notes) ** .5)

def sub_boom(dur=2.2, f0=62, f1=34, vel=.9):
    t = tt(dur); f = f1 + (f0 - f1) * np.exp(-t / 0.18)
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.75) * np.minimum(1, t / 0.004)
    return np.tanh(y * 1.6) / 1.2 * vel

def impact(vel=.7):                         # low impact cinéma doux
    t = tt(2.5); n = lp(rng.normal(0, 1, len(t)), 900) * np.exp(-t / 0.06) * .5
    return sub_boom(2.5, 70, 38, 1) * .9 * vel + n * vel

def whoosh(dur=1.0, f0=200, f1=4500, vel=.35, peak=.6):
    x = rng.normal(0, 1, int(dur * SR)); t = np.linspace(0, 1, len(x))
    e = np.where(t < peak, (t / peak) ** 2, ((1 - t) / (1 - peak)) ** 1.5)
    up = sweep_filter(x, f0, f1, 'lp', 1.0)[: len(x)]
    y = hp(up, 120) * e
    return np.array([y, np.roll(y, 180)]) * vel

def wood(vel=.5, f=190):
    t = tt(.6); y = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t / d) for r, a, d in [(1, 1, .09), (2.3, .6, .05), (4.1, .35, .025), (6.7, .2, .012)])
    y += bp(rng.normal(0, 1, len(t)), 800, 3500) * np.exp(-t / .006) * .4
    return y * vel

def click(vel=.3):                           # click métallique
    t = tt(.25); y = sum(a * np.sin(2 * np.pi * f * t) * np.exp(-t / d) for f, a, d in [(3150, 1, .03), (5230, .6, .02), (7870, .4, .012), (1890, .4, .05)])
    return y * vel

def shimmer(dur=1.6, vel=.12, base=2600):
    t = tt(dur); y = np.zeros_like(t)
    for k in range(9):
        f = base * (1 + k * .37 + rng.random() * .05)
        y += np.sin(2 * np.pi * f * t + rng.random() * 6) * (0.5 + 0.5 * np.sin(2 * np.pi * (5 + k) * t + k))
    e = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 2
    return y * e * vel / 9 * 3

def tick(vel=.12):
    t = tt(.08); return hp(rng.normal(0, 1, len(t)), 6000) * np.exp(-t / .012) * vel

def thump(vel=.5):
    t = tt(.45); f = 48 + 40 * np.exp(-t / .03)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .16) * vel

def riser(dur=2.0, vel=.25):
    x = rng.normal(0, 1, int(dur * SR)); y = sweep_filter(x, 300, 9000, 'lp', 2.2)
    t = np.linspace(0, 1, len(x)); tone = np.sin(2 * np.pi * np.cumsum(220 * 2 ** (t * 1.0)) / SR) * .25
    return (hp(y, 200) + tone * t ** 2) * t ** 2.5 * vel

def bass_note(note, dur, vel=.45):
    t = tt(dur); f = hz(note)
    y = np.sin(2 * np.pi * f * t) + .25 * np.sin(4 * np.pi * f * t) + .08 * np.sin(6 * np.pi * f * t)
    e = np.minimum(1, t / .03) * np.minimum(1, (dur - t) / .12) * (0.75 + 0.25 * np.exp(-t / .4))
    return np.tanh(y * e * 1.3) * vel

# ------------------------------------------------------------------ partition
mus, sfx = Bus(), Bus()
BEAT = 60 / 84
C = {  # accords (MIDI)
 'D5':  [m('D2'), m('A2'), m('E3'), m('A3')],
 'Dadd9':[m('D3'), m('A3'), m('E4'), m('A4')],
 'Bbm7':[m('Bb2'), m('F3'), m('A3'), m('D4'), m('E4')],     # Bbmaj7#11
 'Gm9': [m('G2'), m('D3'), m('Bb3'), m('F4'), m('A4')],
 'Asus':[m('A2'), m('E3'), m('A3'), m('D4'), m('E4')],
 'Dmaj9':[m('D3'), m('A3'), m('C#4'), m('E4'), m('F#4')],
 'Gmaj7/D':[m('D3'), m('G3'), m('B3'), m('F#4'), m('A4')],
}
plan = [  # (début, fin, accord, cutoff, vel)
 (4.4, 8.9, 'D5', 520, .16), (8.4, 11.6, 'Dadd9', 800, .17), (11.25, 13.1, 'Bbm7', 900, .17), (12.85, 14.6, 'Dadd9', 1000, .17),
 (14.3, 16.3, 'Gm9', 1200, .17), (16.0, 18.0, 'Bbm7', 1300, .17), (17.7, 19.7, 'Dadd9', 1400, .17),
 (19.45, 21.95, 'Gm9', 1600, .18), (21.7, 23.4, 'Bbm7', 1800, .18), (23.15, 25.7, 'Asus', 1900, .18),
 (25.4, 27.2, 'D5', 1700, .18), (26.95, 28.55, 'Bbm7', 1900, .18), (28.3, 29.9, 'Gm9', 2100, .19), (29.65, 31.8, 'Asus', 2300, .19),
 (31.5, 33.3, 'Bbm7', 2600, .2), (33.05, 34.6, 'Gm9', 2900, .2), (34.35, 35.8, 'Asus', 3200, .2),
 (35.4, 40.0, 'Dmaj9', 2400, .22), (39.55, 42.8, 'Gmaj7/D', 1800, .19), (42.4, 45.0, 'Dmaj9', 1400, .2),
]
for a, b, ch, fc, v in plan:
    mus.add(a, pad(C[ch], b - a + 1.4, fc, v, att=1.2 if a > 5 else 2.4, rel=1.6))
# drone très grave continu (fondation « architecture »)
t = tt(40.6); dr = (np.sin(2 * np.pi * hz(m('D1')) * t) * .5 + np.sin(2 * np.pi * hz(m('A1')) * t) * .25) * np.minimum(1, t / 5) * np.minimum(1, (40.6 - t) / 3)
mus.add(4.4, lp(dr, 200) * .22)

# --- INTRO 0-4 : presque silence, son grave, résonance métal/verre, une note de piano
sfx.add(0.22, sub_boom(2.6, 58, 32, .55))
sfx.add(0.30, shimmer(1.4, .05, 3400), pan=-.3)          # ligne qui apparaît
mus.add(0.95, bell(m('A4'), 5, .22), pan=.25)             # résonance métal/verre
sfx.add(0.85, shimmer(1.6, .06, 2400), pan=.3)            # tracé du M
mus.add(1.95, piano(m('D2'), 6.5, .75, .7))               # LA note de piano
mus.add(1.97, piano(m('A2'), 6.0, .35, .7) * .5)
sfx.add(2.55, shimmer(1.0, .08, 4200), pan=.2)            # éclat sur le symbole
mus.add(3.0, piano(m('E4'), 4.5, .28, .8), pan=.2)
sfx.add(4.05, whoosh(.9, 150, 2600, .22, .7))             # fente d'ouverture
sfx.add(4.40, thump(.25))

# --- CURIOSITÉ 4-10
for tn, nt, v in [(5.0, 'A3', .3), (6.35, 'E4', .26), (7.25, 'D4', .22), (7.9, 'C#5', .14)]:
    mus.add(tn, piano(m(nt), 4, v, .8), pan=.15)
sfx.add(7.85, click(.08))                                  # barre sur « standard »
sfx.add(8.2, whoosh(.9, 200, 5000, .26, .55), pan=.4)      # scan doré
sfx.add(8.55, impact(.35))
for k in range(5): sfx.add(8.7 + k * .34, shimmer(.6, .025, 3000 + k * 300), pan=(k - 2) * .3)  # lignes de conception
mus.add(9.0, bell(m('E5'), 4, .12), pan=-.3)
sfx.add(9.35, click(.06), pan=.5); sfx.add(9.55, click(.06), pan=-.5)  # cotes
# pulsation électronique très légère dès 7.0
for k in range(int((11.25 - 7.0) / BEAT)): mus.add(7.0 + k * BEAT, thump(.10 + .03 * k / 6))

# --- DÉCOUVERTE 10-20
sfx.add(10.0, whoosh(1.0, 300, 6000, .18, .6), pan=-.2)  # révélation photo
sfx.add(10.15, impact(.4))
mus.add(10.2, bell(m('A4'), 4, .14))
for tc in (11.25, 12.85):                                   # portes de placard
    sfx.add(tc - .34, whoosh(.5, 150, 1800, .3, .8))
    sfx.add(tc - .01, wood(.5, 160)); sfx.add(tc, impact(.32))
    sfx.add(tc + .05, whoosh(.55, 1800, 300, .16, .2))
sfx.add(14.25, whoosh(.75, 180, 2200, .22, .8), pan=-.5)   # panneau cuisine
sfx.add(14.95, wood(.25, 210), pan=-.4)
sfx.add(16.0, whoosh(.5, 400, 3000, .07, .5), pan=.4); sfx.add(17.7, whoosh(.5, 400, 3000, .07, .5), pan=.4)
sfx.add(18.0, shimmer(1.3, .05, 3600), pan=.5)            # lumière qui balaie

# rythme organique 84 BPM
T0 = 11.25; STOP = 39.4
pattern16 = [1, 0, 0, .35, 0, .25, 0, 0, .7, 0, .3, 0, 0, .25, .45, 0]
nb = int((STOP - T0) / BEAT)
for b in range(nb):
    tb = T0 + b * BEAT
    sec = 'A' if tb < 14.3 else 'B' if tb < 19.4 else 'C' if tb < 31.5 else 'D'
    if b % 2 == 0 or sec in 'CD': mus.add(tb, thump(.30 if sec in 'AB' else .38))
    if tb >= 14.3:
        for s in range(4):
            v = pattern16[(b % 4) * 4 + s]
            if v: mus.add(tb + s * BEAT / 4, tick(.06 * v * (1.6 if sec in 'CD' else 1)), pan=.35 if s % 2 else -.25)
    if sec in 'CD' and b % 4 == 2: mus.add(tb, wood(.10, 340), pan=-.5)   # percussion organique
    if sec == 'D' and b % 2 == 1: mus.add(tb + BEAT / 2, wood(.07, 520), pan=.5)

# basse : racines des accords
roots = [(11.25, 12.85, 'Bb1'), (12.85, 14.3, 'D2'), (14.3, 16.0, 'G1'), (16.0, 17.7, 'Bb1'), (17.7, 19.45, 'D2'), (19.45, 21.7, 'G1'),
         (21.7, 23.15, 'Bb1'), (23.15, 25.4, 'A1'), (25.4, 26.95, 'D2'), (26.95, 28.3, 'Bb1'), (28.3, 29.65, 'G1'), (29.65, 31.5, 'A1'),
         (31.5, 33.05, 'Bb1'), (33.05, 34.35, 'G1'), (34.35, 35.4, 'A1'), (35.4, 39.55, 'D2'), (39.55, 42.4, 'D2')]
for a, b, n in roots:
    k = a
    while k < b - .05:
        d = min(BEAT * 2, b - k); mus.add(k, bass_note(m(n), d, .30 if a < 35.4 else .26)); k += d

# piano : motif arpégé (signature mélodique D-A-E) dans les parties instrumentales
def arp(t0, t1, notes, step=BEAT / 2, v=.18, pat=(0, 2, 1, 3, 2, 4, 1, 3)):
    k = 0; t = t0
    while t < t1:
        i = pat[k % len(pat)] % len(notes)
        if not (k % 8 == 7): mus.add(t, piano(notes[i] + 12, 2.5, v * (1 if k % 4 == 0 else .7), .9), pan=(-.3 if k % 2 else .3))
        t += step; k += 1
arp(14.5, 16.0, [m('G3'), m('D4'), m('A4'), m('Bb4'), m('F4')], v=.16)
arp(16.0, 17.7, [m('Bb3'), m('F4'), m('A4'), m('D5'), m('E5')], v=.16)
arp(17.7, 19.3, [m('D3'), m('A3'), m('E4'), m('A4'), m('C#5')], v=.15)
arp(25.6, 31.4, [m('D3'), m('A3'), m('E4'), m('A4'), m('D5')], step=BEAT / 2, v=.12)

# --- MONTÉE 20-30 : volets coulissants, étapes du savoir-faire
for i in range(5):
    tc = 19.45 + i * 1.24
    sfx.add(tc - .42, whoosh(.5, 300, 3800, .13, .75), pan=.6)
    if i == 0: sfx.add(19.45, impact(.3))
    sfx.add(tc, click(.05), pan=-.3)
for i, ts in enumerate([25.6, 26.95, 28.3, 29.65]):
    sfx.add(ts, click(.10), pan=-.4)
    mus.add(ts, bell(m(['A4', 'E5', 'D5', 'A5'][i]), 3, .08), pan=.3)
sfx.add(25.6, shimmer(1.0, .04, 3000))                     # cadre qui se dessine
for k, tk in enumerate([28.45, 28.75, 29.05, 29.3]): sfx.add(tk, wood(.22 - k * .03, 175 + k * 25), pan=(k - 1.5) * .3)  # fabrication
sfx.add(29.65, impact(.35)); sfx.add(30.2, shimmer(1.2, .05, 3600), pan=.4)

# --- APOGÉE 30-38
sfx.add(31.4, whoosh(.8, 200, 2500, .2, .7))
for i, ts in enumerate([31.75, 32.4, 33.05, 33.7, 34.35]):
    sfx.add(ts, thump(.22)); sfx.add(ts + .01, click(.05 + .01 * i), pan=(-.3 if i % 2 else .3))
mus.add(34.35, bell(m('A5'), 3, .1))                       # garantie illimitée
sfx.add(33.5, riser(1.95, .22))
sfx.add(35.35, impact(.55)); sfx.add(35.4, whoosh(1.1, 3500, 250, .22, .15))
# révélation logo : signature courte
def signature(bus_m, bus_s, t0, full=True):
    bus_s.add(t0, sub_boom(3.0, 64, 33, .7))
    bus_s.add(t0 + .02, shimmer(1.8, .07, 3800), pan=.25)
    bus_m.add(t0 + .05, bell(m('D5'), 5, .16), pan=-.2)
    for k, (nt, v) in enumerate([('D4', .42), ('A4', .34), ('E5', .30)]):   # D - A - E : la signature
        bus_m.add(t0 + .18 + k * .24, piano(m(nt), 4.5, v, 1.0), pan=(k - 1) * .25)
    if full: bus_m.add(t0 + .9, piano(m('F#5'), 4.5, .16, 1.0), pan=.3)
signature(mus, sfx, 36.2)
mus.add(36.25, piano(m('D2'), 6, .5, .7))

# --- RÉSOLUTION 38-45 : le rythme s'efface, note longue, signature finale
sfx.add(39.5, impact(.32)); sfx.add(39.55, whoosh(.6, 600, 4000, .1, .4))
mus.add(39.6, piano(m('A3'), 5, .3, .8)); mus.add(39.6, piano(m('D3'), 5, .3, .8))     # note du CTA
sfx.add(40.1, shimmer(1.6, .035, 3000), pan=-.3)
t = tt(6.0); longnote = np.sin(2 * np.pi * hz(m('A4')) * t) * .5 + np.sin(2 * np.pi * hz(m('D5')) * t) * .3
longnote *= np.minimum(1, t / 1.5) * np.minimum(1, (6 - t) / 2.5) * (1 + .08 * np.sin(2 * np.pi * .5 * t))
mus.add(39.0, lp(longnote, 3000) * .06)
signature(mus, sfx, 42.4)
mus.add(42.45, piano(m('D1'), 6, .55, .6))

# ------------------------------------------------------------------ dramaturgie : montée progressive
pts = [(0, -4), (4, -10), (8, -9), (10, -7), (14, -5.5), (20, -4), (25, -3), (30, -1.5), (35, 0), (38.5, 0), (40.5, -2), (45, -2.5)]
tx = np.arange(len(mus.L)) / SR
envdb = np.interp(tx, [p[0] for p in pts], [p[1] for p in pts]); envg = 10 ** (envdb / 20)
mus.L *= envg; mus.R *= envg
# ------------------------------------------------------------------ réverbe & mix
def reverb(L, R, wet=.28, rt=3.2):
    n = int(rt * SR); t = np.arange(n) / SR
    irL = rng.normal(0, 1, n) * np.exp(-t * 6.9 / rt); irR = rng.normal(0, 1, n) * np.exp(-t * 6.9 / rt)
    irL = lp(irL, 5500); irR = lp(irR, 5500); irL[:int(.012 * SR)] = 0; irR[:int(.017 * SR)] = 0
    irL /= np.sqrt((irL ** 2).sum()); irR /= np.sqrt((irR ** 2).sum())
    wl = ss.fftconvolve(hp(L, 180), irL)[: len(L)]; wr = ss.fftconvolve(hp(R, 180), irR)[: len(R)]
    return L + wet * wl, R + wet * wr

mL, mR = reverb(mus.L, mus.R, .34, 3.6)
sL, sR = reverb(sfx.L, sfx.R, .22, 2.6)
cut = lambda x: x[:N]
mL, mR, sL, sR = map(cut, (mL, mR, sL, sR))
fade = np.ones(N); fade[-int(.4 * SR):] = np.linspace(1, 0, int(.4 * SR))

def master(L, R, target=.89):
    L = hp(L, 28); R = hp(R, 28)
    pk = max(np.abs(L).max(), np.abs(R).max()); g = target / pk
    L, R = np.tanh(L * g * 1.05) / np.tanh(1.05), np.tanh(R * g * 1.05) / np.tanh(1.05)
    return L * fade, R * fade

def save(name, L, R):
    wf.write(f'audio/{name}', SR, (np.clip(np.stack([L, R], 1), -1, 1) * 32767).astype(np.int16))

# stems (même gain que le mix)
mixL, mixR = mL + sL * .9, mR + sR * .9
pk = max(np.abs(mixL).max(), np.abs(mixR).max()); g = .89 / pk
save('stem_musique.wav', mL * g * fade, mR * g * fade)
save('stem_sfx.wav', sL * g * .9 * fade, sR * g * .9 * fade)
save('mix_sans_vo.wav', *master(mixL, mixR))

# bed ducké pour la voix off (-5 dB pendant chaque phrase, rampes 150 ms)
VO = [(0.5, 3.4), (4.9, 7.8), (8.8, 13.4), (19.6, 22.6), (23.0, 24.9), (25.7, 30.0), (31.6, 35.2), (36.4, 38.2), (39.6, 40.8)]
duck = np.ones(N); tN = np.arange(N) / SR
for a, b in VO:
    k = np.clip(np.minimum((tN - (a - .15)) / .15, ((b + .25) - tN) / .25), 0, 1)
    duck = np.minimum(duck, 1 - k * (1 - 10 ** (-5 / 20)))
save('bed_pour_vo.wav', *master(mixL * duck, mixR * duck, .80))

# logo sonore isolé
sm, s2 = Bus(), Bus(); signature(sm, s2, .1)
a, b = reverb(sm.L + s2.L, sm.R + s2.R, .3, 3.0)
n = int(4.5 * SR); a, b = a[:n], b[:n]; f = np.ones(n); f[-int(.5 * SR):] = np.linspace(1, 0, int(.5 * SR))
pk = max(abs(a).max(), abs(b).max()); save('signature_sonore.wav', a / pk * .89 * f, b / pk * .89 * f)
print('ok')
