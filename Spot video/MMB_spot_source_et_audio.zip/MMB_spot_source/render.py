"""Rendu frame par frame de spot.html -> MP4 (ou images de contrôle).
Usage :
  python3 render.py h out.mp4            # 16:9
  python3 render.py v out.mp4            # 9:16
  python3 render.py h --stills 2,5.5,10  # images de contrôle dans check/
"""
import os, sys, subprocess, asyncio, pathlib
os.environ.setdefault('PLAYWRIGHT_BROWSERS_PATH', '/opt/pw-browsers')
from playwright.async_api import async_playwright

ROOT = pathlib.Path(__file__).resolve().parent
FPS = 30

async def main():
    fmt = sys.argv[1]
    W, H = (1920, 1080) if fmt == 'h' else (1080, 1920)
    stills = None
    if '--stills' in sys.argv:
        stills = [float(x) for x in sys.argv[sys.argv.index('--stills') + 1].split(',')]
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--force-color-profile=srgb', '--disable-gpu-vsync'])
        pg = await b.new_page(viewport={'width': W, 'height': H}, device_scale_factor=1)
        await pg.goto(f'file://{ROOT}/spot.html?f={fmt}&render=1')
        await pg.evaluate('window.ready')
        await pg.wait_for_timeout(300)
        if stills:
            for t in stills:
                await pg.evaluate(f'renderAt({t})')
                await pg.screenshot(path=str(ROOT / f'check/{fmt}_{t:05.2f}.jpg'), type='jpeg', quality=88)
            await b.close(); return
        out = sys.argv[2]
        dur = await pg.evaluate('window.DUR')
        n = int(round(dur * FPS))
        ff = subprocess.Popen(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', str(FPS),
                               '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'slow', '-crf', '15',
                               '-pix_fmt', 'yuv420p', '-tune', 'film', '-movflags', '+faststart', out], stdin=subprocess.PIPE)
        for i in range(n):
            await pg.evaluate(f'renderAt({i / FPS})')
            ff.stdin.write(await pg.screenshot(type='jpeg', quality=95))
            if i % 150 == 0: print(fmt, i, '/', n, flush=True)
        ff.stdin.close(); ff.wait(); await b.close()

asyncio.run(main())
