import cv2, numpy as np, json
U='/mnt/user-data/uploads/'
N='/root/.claude/uploads/da48706d-ec21-5632-b54f-44928e8dd52f/'
imgs={
 'bland':(N+'0910e90f-image.jpg',(0,0,540,1280)),   # espace vide / standard
 'kitchen':(N+'b4ee0f9e-image.jpg',None),
 'tvslat':(N+'845ac21f-image.jpg',None),
 'salon':(N+'94516b03-image.jpg',None),
 'wardrobe':(N+'ea5a47ee-image.jpg',None),
 'glass':(N+'8fc0e022-image.jpg',None),
 'office':(N+'b19c4379-image.jpg',None),
 'tvwood':(N+'36864a70-image.jpg',None),
 'night':(U+'IMG_9566.JPG',None),
 'slats':(U+'IMG_9565.JPG',None),
 'bath':(N+'2108f7dc-image.jpg',None),
}
meta={}
for k,(f,crop) in imgs.items():
    im=cv2.imread(f if f.startswith('/') else U+f)
    if crop: x0,y0,x1,y1=crop; im=im[y0:y1,x0:x1]
    h,w=im.shape[:2]; s=max(1.0,2600/max(h,w))
    up=cv2.resize(im,(round(w*s),round(h*s)),interpolation=cv2.INTER_LANCZOS4)
    # gentle denoise of jpeg blocks then unsharp
    up=cv2.bilateralFilter(up,5,18,5)
    bl=cv2.GaussianBlur(up,(0,0),1.6); up=cv2.addWeighted(up,1.45,bl,-0.45,0)
    cv2.imwrite(f'assets/{k}.jpg',up,[cv2.IMWRITE_JPEG_QUALITY,90])
    meta[k]={'w':up.shape[1],'h':up.shape[0]}
    print(k,up.shape[1],up.shape[0])

def lines(k,minlen,maxn,thr=(60,150),angtol=6):
    p=imgs[k][0]; im=cv2.imread(p if p.startswith('/') else U+p,0)
    if imgs[k][1]: x0,y0,x1,y1=imgs[k][1]; im=im[y0:y1,x0:x1]
    h,w=im.shape
    e=cv2.Canny(cv2.GaussianBlur(im,(5,5),1.2),*thr)
    L=cv2.HoughLinesP(e,1,np.pi/360,40,minLineLength=minlen,maxLineGap=6)
    out=[]
    for x1,y1,x2,y2 in (L.reshape(-1,4) if L is not None else []):
        ang=abs(np.degrees(np.arctan2(y2-y1,x2-x1)))%180
        ln=np.hypot(x2-x1,y2-y1)
        out.append((ln,[x1/w,y1/h,x2/w,y2/h]))
    out.sort(key=lambda z:-z[0])
    # dedupe near-identical
    keep=[]
    for ln,s in out:
        if all(np.hypot(s[0]-q[0],s[1]-q[1])+np.hypot(s[2]-q[2],s[3]-q[3])>0.02 for q in keep): keep.append([round(v,4) for v in s])
        if len(keep)>=maxn: break
    print(k,'lines',len(keep))
    return keep
meta['lines']={'tvslat':lines('tvslat',45,170),'night':lines('night',40,140)}
json.dump(meta,open('assets/meta.json','w'))
